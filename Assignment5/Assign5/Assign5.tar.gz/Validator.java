import java.util.*;
import java.io.*;
import java.lang.*;

public class Validator
{
	// validate menu choices
	public static boolean checkMenuChoice(int choice)
	{
		if (choice < 1 || choice>3)
			return false;
		return true;
	}

	// validate non empty values for name, email and cellNumber
	public static boolean checkInput(String input)
	{
		if(input.length() == 0)
			return false;
		return true;
	}
}