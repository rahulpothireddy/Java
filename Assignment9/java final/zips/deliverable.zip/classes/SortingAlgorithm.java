import javax.swing.JButton;

public abstract class SortingAlgorithm {

	protected int array[];
	protected String arrayOrder;
	protected SortAnimationPanel sortAnimationPanel;
	protected SortPanel sortPanel;
	protected int millisecondsSleep = 10;
	protected boolean stop = false;
	protected boolean pause = false;
	protected int flag[] = null;
	protected JButton stopButton = null;
	
	public abstract void sort();
	
	public SortingAlgorithm(){
		 stop = false;
	}
	
	public void initialize(int[] array, String order) {
		this.array = array;
		this.arrayOrder = order;
	}
	
	public void setTimeSleep(int milliseconds) {
		millisecondsSleep = milliseconds;
	}
	
	public void setPanel(SortPanel sortPanel) {
		this.sortPanel = sortPanel;
	}
	
	public void setStopButton(JButton stopButton) {
		this.stopButton = stopButton;
	}
	
	public void setFlag(int flag[]) {
		this.flag = flag;
	}
	
	public void pause() {
		pause = !pause;
	}
	
	public void pauseWait() {
		while (pause) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				e.printStackTrace();
				break;
			}
		}
	}
	
	public void stop() {
		stop = true;
	}
	
	public void end() {
		synchronized (flag) {
			if (flag[0] == 0) {
				flag[0] = 1;
			}
			else {
				sortPanel.resetButtons();
			}
		}
		stopButton.setEnabled(false);
	}
	
	public void printNumbers(int[] array) {
        
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
            	System.out.print(", ");
            }
        }
        System.out.println("\n");
    }
}
