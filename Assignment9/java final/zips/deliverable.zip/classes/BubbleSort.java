
public class BubbleSort extends SortingAlgorithm{

	public BubbleSort(SortAnimationPanel sortAnimationPanel) {
		super();
		this.sortAnimationPanel = sortAnimationPanel;
	}
	  

    // logic to sort the elements
    public void sort(){
        int n = array.length;
        int k;
        boolean swap = false;
                
        for (int m = n; m >= 0; m--) {
            for (int i = 0; i < n - 1; i++) {
            	if (stop) {
            		end();
            		return;
            	}
            	pauseWait();
            	
                k = i + 1;
                if (arrayOrder.equals("Asceding")) {
                	swap = array[i] > array[k];
                }
                else {
                	swap = array[i] < array[k];
                }
                
                if (swap) {
                    swapNumbers(i, k, array);
                    if (sortAnimationPanel != null) {
                    	sortAnimationPanel.repaint();
                    }
                    
                    try {
						Thread.sleep(millisecondsSleep);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
                }
            }
        }
        
        end();
    }
  
    private void swapNumbers(int i, int j, int[] array) {
        int temp;
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
  
   
}