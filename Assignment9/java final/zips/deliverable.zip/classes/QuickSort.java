public class QuickSort extends SortingAlgorithm{
     
	public QuickSort(SortAnimationPanel sortAnimationPanel) {
		super();
		this.sortAnimationPanel = sortAnimationPanel;
	}
	
	public void sort() {
        int length = array.length;
        quickSort(0, length - 1);
        end();
    }
 
    private void quickSort(int lowerIndex, int higherIndex) {
         
        int i = lowerIndex;
        int j = higherIndex;
        // calculate pivot number, I am taking pivot as middle index number
        int pivot = array[lowerIndex+(higherIndex-lowerIndex)/2];
        boolean b1 = false, b2 = false;
        
        // Divide into two arrays
        while (i <= j) {
        	if (stop) {
        		end();
        		return;
        	}
        	pauseWait();
           
        	if (arrayOrder.equals("Asceding")) {
        		b1 = array[i] < pivot;
        	}
        	else {
        		b1 = array[i] > pivot;
        	}
        	
            while (b1) {
                i++;
                
                if (arrayOrder.equals("Asceding")) {
            		b1 = array[i] < pivot;
            	}
            	else {
            		b1 = array[i] > pivot;
            	}
                
            }
            
            if (arrayOrder.equals("Asceding")) {
        		b2 = array[j] > pivot;
        	}
        	else {
        		b2 = array[j] < pivot;
        	}
            
            while (b2) {
                j--;
                
                if (arrayOrder.equals("Asceding")) {
            		b2 = array[j] > pivot;
            	}
            	else {
            		b2 = array[j] < pivot;
            	}
            }
                        
            if (i <= j) {
                exchangeNumbers(i, j);
                //move index to next position on both sides
                i++;
                j--;
                
                if (sortAnimationPanel != null) {
                	sortAnimationPanel.repaint();
                }
                
                try {
					Thread.sleep(millisecondsSleep);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
            }
        }
        // call quickSort() method recursively
        if (lowerIndex < j)
            quickSort(lowerIndex, j);
        if (i < higherIndex)
            quickSort(i, higherIndex);
        
    }
 
    private void exchangeNumbers(int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
     

}