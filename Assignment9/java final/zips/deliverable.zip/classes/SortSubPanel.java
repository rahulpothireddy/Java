import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;

public class SortSubPanel extends JPanel{
	private SortAnimationPanel sortAnimationPanel;
	private String[] sortingAlgorithmStrings = {"Bubble Sort", "Insertion Sort", "Quick Sort"};
	private JComboBox sortingAlgorithms = new JComboBox(sortingAlgorithmStrings);
	private String[] orderStrings = {"Asceding", "Desceding"};
	private JComboBox orders = new JComboBox(orderStrings);
	private JButton stopButton = new JButton("Stop");
	
	public SortSubPanel(int width, int height) {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		sortAnimationPanel = new SortAnimationPanel(width, height);
		add(sortAnimationPanel);
		
		sortingAlgorithms.setEnabled(false);
		sortingAlgorithms.setFocusable(false);
		orders.setEnabled(false);
		orders.setFocusable(false);
		stopButton.setEnabled(false);
		stopButton.setFocusable(false);
		
		stopButton.addActionListener(new ActionListener()
	    {
	      public void actionPerformed(ActionEvent e)
	      {
	    	  stopButton.setEnabled(false);
	    	  sortAnimationPanel.stop();
	      }
	    });
		
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new FlowLayout());
		bottomPanel.add(sortingAlgorithms);
		bottomPanel.add(orders);
		bottomPanel.add(stopButton);
		add(bottomPanel);
	}
	
	public int[] createArray(String arrayOrder) {
		return sortAnimationPanel.createArray(arrayOrder);
	}
	
	public void setArray(int array[]) {
		sortAnimationPanel.setArray(array);
	}
	
	public void pause() {
		sortAnimationPanel.pause();
	}
	
	public void setEnabledCheckBox(boolean b) {
		sortingAlgorithms.setEnabled(b);
		orders.setEnabled(b);
	}
	
	public void setEnabledStopButton(boolean b) {
		stopButton.setEnabled(b);
	}
	
	public Thread createThread(SortPanel sortPanel, int flag[], String speedMode) {
		sortAnimationPanel.init(sortPanel, flag, stopButton, (String)sortingAlgorithms.getSelectedItem(), (String)orders.getSelectedItem());
		setSpeed(speedMode);
		return new Thread(sortAnimationPanel);
	}
	
	public void setSpeed(String speedMode) {
		sortAnimationPanel.setTimeSleep(speedMode);
	}
}

