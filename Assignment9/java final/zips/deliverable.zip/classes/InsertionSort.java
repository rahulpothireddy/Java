public class InsertionSort extends SortingAlgorithm{
 
	public InsertionSort(SortAnimationPanel sortAnimationPanel) {
		super();
		this.sortAnimationPanel = sortAnimationPanel;
	}
	
    public void sort(){
        int temp;
        boolean swap;
        
        for (int i = 1; i < array.length; i++) {
            for(int j = i ; j > 0 ; j--){
            	if (stop) {
            		end();
            		return;
            	}
            	pauseWait();
            	
            	if (arrayOrder.equals("Asceding")) {
            		swap = array[j] < array[j-1];
            	}
            	else {
            		swap = array[j] > array[j-1];
            	}
            	
                if(swap){
                    temp = array[j];
                    array[j] = array[j-1];
                    array[j-1] = temp;
                    
                    if (sortAnimationPanel != null) {
                    	sortAnimationPanel.repaint();
                    }
                    
                    try {
						Thread.sleep(millisecondsSleep);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
                }
            }
        }
        
        end();
    }
    
}