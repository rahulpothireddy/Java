import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;


public class SortPanel extends JPanel{

	private SortSubPanel firstSubPanel, secondSubPanel;
	private String[] arrayOrderStrings = {"Random", "Asceding", "Desceding"};
	private JComboBox arrayOrders = new JComboBox(arrayOrderStrings);
	private String[] speedStrings = {"Fast", "Medium", "Slow"};
	private JComboBox speeds = new JComboBox(speedStrings);
	private SortPanel thisPanel = this;
	private Thread t1 = null, t2 = null;
	private int flag[] = null;
	
	//bottom panel variables
	private JPanel bottomPanel;
	private JButton populateArrayButton = new JButton("Populate Array");
	private JButton sortButton = new JButton("Sort");
	private JButton pauseButton = new JButton("Pause");
	
	
	public SortPanel(int width, int height) {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setPreferredSize(new Dimension(width, height));
		
		JPanel emptyPanel = new JPanel();
		emptyPanel.setPreferredSize(new Dimension(20, 20));
		JPanel horizontalPanel = new JPanel();
		horizontalPanel.setLayout(new BoxLayout(horizontalPanel, BoxLayout.LINE_AXIS));
		
		firstSubPanel = new SortSubPanel(width, (int)(height/1.1));
		secondSubPanel = new SortSubPanel(width, (int)(height/1.1));
		
		horizontalPanel.add(firstSubPanel);
		horizontalPanel.add(emptyPanel);
		horizontalPanel.add(secondSubPanel);
		add(horizontalPanel);
		
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new FlowLayout());
		populateArrayButton = new JButton("Populate Array");
		populateArrayButton.setFocusable(false);
		arrayOrders.setFocusable(false);
		pauseButton.setFocusable(false);
		sortButton = new JButton("Sort");
		sortButton.setFocusable(false);
		sortButton.setEnabled(false);
		speeds.setEnabled(false);
		speeds.setFocusable(false);
		pauseButton.setEnabled(false);
		bottomPanel.add(populateArrayButton);
		bottomPanel.add(arrayOrders);
		bottomPanel.add(sortButton);
		bottomPanel.add(speeds);
		bottomPanel.add(pauseButton);
		
		speeds.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		       firstSubPanel.setSpeed((String)speeds.getSelectedItem());
		       secondSubPanel.setSpeed((String)speeds.getSelectedItem());
		    }
		});
		
		populateArrayButton.addActionListener(new ActionListener()
	    {
	      public void actionPerformed(ActionEvent e)
	      {
	    	  firstSubPanel.setEnabledCheckBox(true);
	    	  secondSubPanel.setEnabledCheckBox(true);
	    	  populateArrayButton.setEnabled(false);
	    	  arrayOrders.setEnabled(false);
	    	  sortButton.setEnabled(true);
	    	  speeds.setEnabled(true);
	    	  int array[] = firstSubPanel.createArray((String)arrayOrders.getSelectedItem());
	    	  firstSubPanel.setArray(array);
	    	  secondSubPanel.setArray(array);
	      }
	    });
		
		sortButton.addActionListener(new ActionListener()
	    {
	      public void actionPerformed(ActionEvent e)
	      {
	    	  sortButton.setEnabled(false);
	    	  firstSubPanel.setEnabledCheckBox(false);
	    	  secondSubPanel.setEnabledCheckBox(false);
	    	  firstSubPanel.setEnabledStopButton(true);
	    	  secondSubPanel.setEnabledStopButton(true);
	    	  pauseButton.setEnabled(true);
	    	  flag = new int[1];
	    	  t1 = firstSubPanel.createThread(thisPanel, flag, (String)speeds.getSelectedItem());
	    	  t2 = secondSubPanel.createThread(thisPanel, flag, (String)speeds.getSelectedItem());
	    	  t1.start();
	    	  t2.start();
	    
	      }
	    });
		
		pauseButton.addActionListener(new ActionListener()
	    {
	      public void actionPerformed(ActionEvent e)
	      {
	    	  if (pauseButton.getText().equals("Pause")) {
	    		  pauseButton.setText("Resume");
	    	  }
	    	  else {
	    		  pauseButton.setText("Pause");
	    	  }
	    	  
	    	  firstSubPanel.pause();
	    	  secondSubPanel.pause();
	      }
	    });
		
		
		add(bottomPanel);
	}
	
	public void resetButtons() {
	  populateArrayButton.setEnabled(true);
  	  arrayOrders.setEnabled(true);
	  sortButton.setEnabled(false);
	  speeds.setEnabled(false);
	  pauseButton.setEnabled(false);
	}
}
