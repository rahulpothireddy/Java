import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JPanel;

public class SortAnimationPanel extends JPanel implements Runnable{
		
	private int array[];
	private int PANEL_WIDTH = 0, PANEL_HEIGHT = 0;
	private String arrayOrder = "";
	private SortingAlgorithm sortingAlgorithm = null;
	
	public SortAnimationPanel(int width, int height) {
		setPreferredSize(new Dimension(width, height));
	}
	
	public void init(SortPanel sortPanel, int flag[], JButton stopButton, String algorithmName, String arrayOrder) {
		this.arrayOrder = arrayOrder;
		if (algorithmName.equals("Bubble Sort")) {
			sortingAlgorithm = new BubbleSort(this);
		}
		else if (algorithmName.equals("Insertion Sort")) {
			sortingAlgorithm = new InsertionSort(this);
		}
		else {
			sortingAlgorithm = new QuickSort(this);
		}
		
		sortingAlgorithm.setPanel(sortPanel);
		sortingAlgorithm.setFlag(flag);
		sortingAlgorithm.setStopButton(stopButton);
	}
	
	public void setTimeSleep(String speedMode) {
		int milliSecondsSleep = 100;

		if (speedMode.equals("Fast")) {
			milliSecondsSleep = 1;
		}
		else if (speedMode.equals("Medium")) {
			milliSecondsSleep = 5;
		}
		else {
			milliSecondsSleep = 10;
		}
		
		if (sortingAlgorithm != null) {
			sortingAlgorithm.setTimeSleep(milliSecondsSleep);
		}
	}
	
	public void pause() {
		if (sortingAlgorithm != null) {
			sortingAlgorithm.pause();		}
	}
	
	public void stop() {
		if (sortingAlgorithm != null) {
			sortingAlgorithm.stop();
		}
	}
	
	public int[] createArray(String arrayOrder) {
		if (arrayOrder.equals("Random")) {
			return createRandomArray();
		}
		else if (arrayOrder.equals("Asceding")) {
			return createAscedingArray();
		}
		else {
			return createDescedingArray();
		}
	}
	
	public int [] createRandomArray() {
		int array[] = new int[PANEL_WIDTH];
		Random random = new Random();
		
		for (int i = 0; i < PANEL_WIDTH; i++) {
			array[i] = random.nextInt(PANEL_HEIGHT);
		}
		return array;
	}
	
	public int[] createAscedingArray() {
		int array[] = new int[PANEL_WIDTH];
		
		for (int i = 0; i < PANEL_WIDTH; i++) {
			if (i > PANEL_HEIGHT) {
				array[i] = PANEL_HEIGHT;
			}
			else {
				array[i] = i;
			}
			
		}
		return array;
	}
	
	public int[] createDescedingArray() {
		int array[] = new int[PANEL_WIDTH];
		Random random = new Random();
		
		for (int i = PANEL_WIDTH-1; i >= 0; i--) {
			if (i > PANEL_HEIGHT) {
				array[PANEL_WIDTH-i-1] = PANEL_HEIGHT;
			}
			else {
				array[PANEL_WIDTH-i-1] = i;
			}
		}
		
		return array;
	}
	
	public void setArray(int array[]) {
		this.array = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			this.array[i] = array[i];
		}
		repaint();
	}
	
	public int[] getArray() {
		return array;
	}
	
	
	public void paintComponent (Graphics g)
	{
	    super.paintComponent (g);
	    PANEL_WIDTH = this.getWidth();
	    PANEL_HEIGHT = this.getHeight();
	    
	    if (array != null) {
	    	 for (int i = 0; i < PANEL_WIDTH; i++) {
	 	    	g.drawRect(i, PANEL_HEIGHT-array[i], 1, array[i]);  
	 		    g.setColor(Color.BLUE);  
	 		    g.fillRect(i, PANEL_HEIGHT-array[i], 1, array[i]);  
	 	    }
	    }
	}

	public void run() {
		sortingAlgorithm.initialize(array, arrayOrder);
		sortingAlgorithm.sort();
		
		/*sortingAlgorithm.initialize(array, arrayOrder);
		//sortingAlgorithm.printNumbers(array);

		boolean sorted = sortingAlgorithm.step();
        repaint();
        try {
	        while (!sorted) {
	        	Thread.sleep(milliSecondsSleep);
				sorted = sortingAlgorithm.step();
	        	repaint();
	        	
	        	
        }
        } catch (InterruptedException e) {
			e.printStackTrace();
		}*/
  

	}
}
